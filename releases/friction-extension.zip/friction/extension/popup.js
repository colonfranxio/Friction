"use strict";
(() => {
  // ../../packages/shared/src/constants.ts
  var PORTS = { api: 8787, mock: 8788, dashboard: 5173 };
  var DEFAULT_API_URL = `http://127.0.0.1:${PORTS.api}`;
  var QUIZ_WINDOW_MS = 10 * 60 * 1e3;
  var LEVEL_LABELS = {
    1: { bloom: "Remember / Understand", role: "Socratic", friction: "Max friction" },
    2: { bloom: "Apply", role: "Scaffolder", friction: "Medium friction" },
    3: { bloom: "Analyze / Evaluate", role: "Challenger", friction: "Reverse friction" },
    4: { bloom: "Create", role: "Normal", friction: "No friction" }
  };

  // ../../packages/shared/src/seed.ts
  var SEED_IDS = {
    educator: "11111111-1111-4111-8111-111111111111",
    demoStudent: "22222222-2222-4222-8222-222222222222",
    tree: "33333333-3333-4333-8333-333333333333",
    pillars: {
      foundations: "44444444-4444-4444-8444-000000000001",
      effects: "44444444-4444-4444-8444-000000000002",
      apps: "44444444-4444-4444-8444-000000000003"
    },
    nodes: {
      jsx: "55555555-5555-4555-8555-000000000001",
      props: "55555555-5555-4555-8555-000000000002",
      useState: "55555555-5555-4555-8555-000000000003",
      useEffect: "55555555-5555-4555-8555-000000000004",
      dataFetching: "55555555-5555-4555-8555-000000000005",
      customHooks: "55555555-5555-4555-8555-000000000006",
      context: "55555555-5555-4555-8555-000000000007",
      performance: "55555555-5555-4555-8555-000000000008"
    }
  };
  var N = SEED_IDS.nodes;
  var P = SEED_IDS.pillars;
  var DEMO_STUDENT_LEVELS = {
    [N.jsx]: 3,
    [N.props]: 3,
    [N.useState]: 4,
    [N.useEffect]: 1,
    [N.dataFetching]: 1,
    [N.customHooks]: 1,
    [N.context]: 2,
    [N.performance]: 1
  };

  // src/lib/storage.ts
  var DEFAULT_DASHBOARD_URL = "http://127.0.0.1:5173";
  var DEFAULT_SETTINGS = {
    studentId: SEED_IDS.demoStudent,
    apiUrl: DEFAULT_API_URL,
    enabled: true,
    promptBypassReadySha: "",
    dashboardUrl: DEFAULT_DASHBOARD_URL
  };
  async function getSettings() {
    const s = await chrome.storage.local.get(["studentId", "apiUrl", "enabled", "promptBypassReadySha", "dashboardUrl"]);
    return {
      studentId: typeof s.studentId === "string" && s.studentId ? s.studentId : DEFAULT_SETTINGS.studentId,
      apiUrl: typeof s.apiUrl === "string" && s.apiUrl ? s.apiUrl.replace(/\/$/, "") : DEFAULT_SETTINGS.apiUrl,
      enabled: typeof s.enabled === "boolean" ? s.enabled : DEFAULT_SETTINGS.enabled,
      promptBypassReadySha: typeof s.promptBypassReadySha === "string" ? s.promptBypassReadySha.trim() : "",
      dashboardUrl: typeof s.dashboardUrl === "string" && s.dashboardUrl.trim() ? s.dashboardUrl.trim().replace(/\/+$/, "") : DEFAULT_DASHBOARD_URL
    };
  }
  async function saveSettings(patch) {
    await chrome.storage.local.set(patch);
  }

  // src/popup.ts
  var $ = (id) => document.getElementById(id);
  var send = (m) => chrome.runtime.sendMessage(m);
  async function render() {
    let s;
    try {
      s = await send({ type: "friction:status" });
    } catch {
      $("status").textContent = "Offline";
      $("status-dot").style.background = "#8F86A8";
      $("bypass").disabled = true;
      return;
    }
    $("status").textContent = !s.enabled ? "Paused" : s.online ? "Online" : "Offline";
    $("status-dot").style.background = s.online ? "#6D4AFF" : "#8F86A8";
    $("enabled").checked = s.enabled;
    const last = s.last;
    if (last?.node_id && last.level) {
      const lvl = s.paused ? 4 : last.level;
      const state = s.paused ? "bypassed" : lvl === 4 ? "mastered" : "learning";
      $("current").dataset.state = state;
      $("kicker").textContent = state === "bypassed" ? "Bypassed" : state === "mastered" ? "No friction \u2605" : "Learning";
      $("concept").textContent = last.concept_name ?? "Current concept";
      $("chip").textContent = `L${lvl} \xB7 ${LEVEL_LABELS[lvl].role}`;
      $("chip").className = lvl === 4 ? "chip chip-green" : "chip";
      $("friction").textContent = s.paused ? "Bypassed" : LEVEL_LABELS[lvl].friction;
      $("current").hidden = false;
      $("no-current").hidden = true;
    } else {
      $("current").hidden = true;
      $("no-current").hidden = false;
    }
    const btn = $("bypass");
    const quota = s.bypass_quota;
    const what = s.prompt_bypass ? "message" : "concept";
    $("bypass-label").textContent = `Bypass this ${what}`;
    $("bypass-left").textContent = quota === null ? "\xD7\u2013" : `\xD7${quota}`;
    $("bypass-left").setAttribute("aria-label", quota === null ? "Bypasses left unknown" : `${quota} bypasses left`);
    $("bypass-note").textContent = s.prompt_bypass ? "Re-sends your last message to Claude without friction. Uses one bypass and notifies your teacher." : "Re-sends your last message without friction and pauses friction on this concept until reset. Uses one bypass and notifies your teacher.";
    btn.disabled = !s.online || !s.enabled || !last?.node_id || s.paused || quota === 0;
  }
  async function init() {
    const settings = await getSettings();
    $("student").value = settings.studentId;
    $("api").value = settings.apiUrl;
    $("ready-sha").value = settings.promptBypassReadySha;
    $("dash").value = settings.dashboardUrl;
    let windowId;
    const openBtn = $("open-map");
    openBtn.disabled = true;
    chrome.windows?.getCurrent?.().then((w) => {
      windowId = w.id;
      openBtn.disabled = windowId === void 0;
    }).catch(() => $("map-msg").textContent = "Couldn\u2019t find this window. Close and reopen the popup.");
    $("open-map").addEventListener("click", () => {
      $("map-msg").textContent = "";
      if (!chrome.sidePanel?.open) {
        $("map-msg").textContent = "Your Chrome is too old for side panels (needs Chrome 116+).";
        return;
      }
      if (windowId === void 0) {
        $("map-msg").textContent = "Couldn\u2019t find this window. Close and reopen the popup, then try again.";
        return;
      }
      chrome.sidePanel.open({ windowId }).then(
        () => window.close(),
        (e) => $("map-msg").textContent = `Chrome didn\u2019t open the side panel (${String(e?.message ?? e)}).`
      );
    });
    $("enabled").addEventListener("change", async (e) => {
      await saveSettings({ enabled: e.target.checked });
      await render();
    });
    $("bypass").addEventListener("click", async () => {
      const btn = $("bypass");
      if (btn.disabled) return;
      btn.disabled = true;
      $("msg").textContent = "";
      const copy = $("copy-question");
      copy.hidden = true;
      try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (tab?.id === void 0) throw new Error("no tab");
        const r = await chrome.tabs.sendMessage(tab.id, { type: "friction:bypass-resend" });
        const scopeNote = r.ok && r.scope_applied === "concept" ? " Friction stays off for this concept until reset." : "";
        if (r.ok && r.not_sent_reason && r.prompt) {
          const prompt = r.prompt;
          $("msg").textContent = `Bypass used (${r.remaining_quota} left), not sent: ${r.not_sent_reason}. Your teacher was notified.`;
          copy.hidden = false;
          copy.textContent = "Copy question";
          copy.onclick = () => void navigator.clipboard.writeText(prompt).then(() => copy.textContent = "Copied", () => copy.textContent = "Copy failed");
        } else $("msg").textContent = !r.ok ? r.message : (r.resent ? `Re-sent without friction. ${r.remaining_quota} left. Your teacher has been notified.` : `Bypass used (${r.remaining_quota} left). Your message is in the box; press Send and it goes out without friction.`) + scopeNote;
      } catch {
        $("msg").textContent = "Open your claude.ai tab (reload it if needed), then click Bypass.";
      }
      await render();
    });
    $("settings-form").addEventListener("submit", async (e) => {
      e.preventDefault();
      await saveSettings({
        studentId: $("student").value.trim(),
        apiUrl: $("api").value.trim().replace(/\/$/, ""),
        promptBypassReadySha: $("ready-sha").value.trim(),
        dashboardUrl: $("dash").value.trim().replace(/\/+$/, "")
      });
      $("msg").textContent = "Settings saved.";
      await render();
    });
    $("version").textContent = `v${chrome.runtime.getManifest().version}`;
    await render();
  }
  void init();
})();
