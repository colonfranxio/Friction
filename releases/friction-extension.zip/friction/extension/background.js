"use strict";
(() => {
  // ../../packages/shared/src/constants.ts
  var PORTS = { api: 8787, mock: 8788, dashboard: 5173 };
  var DEFAULT_API_URL = `http://127.0.0.1:${PORTS.api}`;
  var EXTENSION_TIMEOUT_MS = 4500;
  var QUIZ_WINDOW_MS = 10 * 60 * 1e3;

  // ../../packages/shared/src/client.ts
  var ApiError = class extends Error {
    constructor(status, code, message) {
      super(message);
      this.status = status;
      this.code = code;
      this.name = "ApiError";
    }
    status;
    code;
  };
  function createFrictionClient(baseUrl, fetchImpl = (i, r) => fetch(i, r)) {
    const base = baseUrl.replace(/\/$/, "");
    async function call(method, path, body, signal) {
      const res = await fetchImpl(base + path, {
        method,
        headers: body === void 0 ? void 0 : { "content-type": "application/json" },
        body: body === void 0 ? void 0 : JSON.stringify(body),
        signal
      });
      if (res.status === 204) return void 0;
      const text = await res.text();
      const json = text ? JSON.parse(text) : void 0;
      if (!res.ok) {
        const err = json?.error;
        throw new ApiError(res.status, err?.code ?? "internal", err?.message ?? res.statusText);
      }
      return json;
    }
    return {
      baseUrl: base,
      health: () => call("GET", "/health"),
      parseTree: (b) => call("POST", "/trees/parse", b),
      getTree: (treeId) => call("GET", `/trees/${treeId}`),
      createNode: (treeId, b) => call("POST", `/trees/${treeId}/nodes`, b),
      updateNode: (nodeId, b) => call("PATCH", `/nodes/${nodeId}`, b),
      deleteNode: (nodeId) => call("DELETE", `/nodes/${nodeId}`),
      createEdge: (b) => call("POST", "/edges", b),
      deleteEdge: (parentId, childId) => call("DELETE", `/edges/${parentId}/${childId}`),
      renamePillar: (pillarId, b) => call("PATCH", `/pillars/${pillarId}`, b),
      treeStudents: (treeId) => call("GET", `/trees/${treeId}/students`),
      treeActivity: (treeId) => call("GET", `/trees/${treeId}/activity`),
      getStudent: (studentId) => call("GET", `/students/${studentId}`),
      intercept: (b, signal) => call("POST", "/intercept", b, signal),
      responses: (b) => call("POST", "/responses", b),
      bypass: (b) => call("POST", "/bypass", b),
      heartbeat: (b) => call("POST", "/heartbeat", b),
      demoReset: (b) => call("POST", "/demo/reset", b),
      /** Raw text/plain response. Consume to EOF; a body-read rejection means interrupted, not complete. Caller abort is separate. */
      chat: (b, signal) => fetchImpl(base + "/chat", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(b),
        signal
      }),
      /** Use with `new EventSource(url)`; listen per ServerEvent type. */
      eventsUrl: (treeId) => `${base}/events?tree_id=${encodeURIComponent(treeId)}`
    };
  }

  // ../../packages/shared/src/seed.ts
  var SEED_IDS = {
    educator: "11111111-1111-4111-8111-111111111111",
    demoStudent: "22222222-2222-4222-8222-222222222222",
    tree: "33333333-3333-4333-8333-333333333333",
    pillars: {
      foundations: "44444444-4444-4444-8444-000000000001",
      effects: "44444444-4444-4444-8444-000000000002",
      apps: "44444444-4444-4444-8444-000000000003"
    },
    nodes: {
      jsx: "55555555-5555-4555-8555-000000000001",
      props: "55555555-5555-4555-8555-000000000002",
      useState: "55555555-5555-4555-8555-000000000003",
      useEffect: "55555555-5555-4555-8555-000000000004",
      dataFetching: "55555555-5555-4555-8555-000000000005",
      customHooks: "55555555-5555-4555-8555-000000000006",
      context: "55555555-5555-4555-8555-000000000007",
      performance: "55555555-5555-4555-8555-000000000008"
    }
  };
  var N = SEED_IDS.nodes;
  var P = SEED_IDS.pillars;
  var DEMO_STUDENT_LEVELS = {
    [N.jsx]: 3,
    [N.props]: 3,
    [N.useState]: 4,
    [N.useEffect]: 1,
    [N.dataFetching]: 1,
    [N.customHooks]: 1,
    [N.context]: 2,
    [N.performance]: 1
  };

  // src/lib/bypass-gate.ts
  var READY_SHA_RE = /^[a-f0-9]{40}$/i;
  function promptBypassEnabled(health, readySha) {
    if (!health || health.contract_version < 4) return false;
    return health.mode.server === "mock" || READY_SHA_RE.test(readySha.trim());
  }

  // src/lib/storage.ts
  var DEFAULT_DASHBOARD_URL = "http://127.0.0.1:5173";
  var DEFAULT_SETTINGS = {
    studentId: SEED_IDS.demoStudent,
    apiUrl: DEFAULT_API_URL,
    enabled: true,
    promptBypassReadySha: "",
    dashboardUrl: DEFAULT_DASHBOARD_URL
  };
  async function getSettings() {
    const s = await chrome.storage.local.get(["studentId", "apiUrl", "enabled", "promptBypassReadySha", "dashboardUrl"]);
    return {
      studentId: typeof s.studentId === "string" && s.studentId ? s.studentId : DEFAULT_SETTINGS.studentId,
      apiUrl: typeof s.apiUrl === "string" && s.apiUrl ? s.apiUrl.replace(/\/$/, "") : DEFAULT_SETTINGS.apiUrl,
      enabled: typeof s.enabled === "boolean" ? s.enabled : DEFAULT_SETTINGS.enabled,
      promptBypassReadySha: typeof s.promptBypassReadySha === "string" ? s.promptBypassReadySha.trim() : "",
      dashboardUrl: typeof s.dashboardUrl === "string" && s.dashboardUrl.trim() ? s.dashboardUrl.trim().replace(/\/+$/, "") : DEFAULT_DASHBOARD_URL
    };
  }
  async function getLastIntercept() {
    const { lastIntercept } = await chrome.storage.local.get("lastIntercept");
    return lastIntercept ?? null;
  }
  async function setLastIntercept(v) {
    await chrome.storage.local.set({ lastIntercept: v });
  }

  // src/background.ts
  var API_BUDGET_MS = EXTENSION_TIMEOUT_MS - 500;
  var concepts = /* @__PURE__ */ new Map();
  var conceptsFor = "";
  var refreshing = null;
  function refreshConcepts(client, studentId) {
    if (refreshing) return refreshing;
    refreshing = (async () => {
      try {
        const s = await client.getStudent(studentId);
        if (!s.tree_id) return;
        const tree = await client.getTree(s.tree_id);
        concepts = new Map(tree.nodes.map((n) => [n.id, n.concept_name]));
        conceptsFor = `${client.baseUrl}|${studentId}`;
      } catch {
      } finally {
        refreshing = null;
      }
    })();
    return refreshing;
  }
  function conceptName(client, studentId, nodeId) {
    if (!nodeId) return null;
    const key = `${client.baseUrl}|${studentId}`;
    if (conceptsFor !== key || !concepts.has(nodeId)) void refreshConcepts(client, studentId);
    return conceptsFor === key ? concepts.get(nodeId) ?? null : null;
  }
  async function healthWithin(client, ms) {
    let t;
    try {
      return await Promise.race([client.health(), new Promise((_, rej) => t = setTimeout(() => rej(new Error("timeout")), ms))]);
    } catch {
      return null;
    } finally {
      clearTimeout(t);
    }
  }
  async function handleIntercept(m) {
    const s = await getSettings();
    if (!s.enabled) return { outcome: { passthrough: true, reason: "disabled" }, concept_name: null };
    const client = createFrictionClient(s.apiUrl);
    try {
      const r = await client.intercept(
        {
          student_id: s.studentId,
          raw_prompt: m.raw_prompt,
          app_source: "claude_web",
          conversation_id: m.conversation_id,
          previous_assistant_text: m.previous_assistant_text
        },
        AbortSignal.timeout(API_BUDGET_MS)
      );
      let concept = conceptName(client, s.studentId, r.node_id);
      if (r.node_id && !concept) {
        await Promise.race([refreshConcepts(client, s.studentId), new Promise((res) => setTimeout(res, 400))]);
        concept = concepts.get(r.node_id) ?? null;
      }
      const last = {
        node_id: r.node_id,
        level: r.level,
        concept_name: concept,
        intercept_id: r.intercept_id,
        at: (/* @__PURE__ */ new Date()).toISOString()
      };
      if (r.node_id) await setLastIntercept(last);
      if (!r.node_id) return { outcome: { passthrough: true, reason: "no_match" }, concept_name: null };
      return { outcome: { passthrough: false, response: r }, concept_name: concept };
    } catch (err) {
      console.warn("[friction] intercept failed, passing prompt through", err);
      return { outcome: { passthrough: true, reason: err instanceof ApiError ? "error" : "offline" }, concept_name: null };
    }
  }
  async function handleStatus() {
    const s = await getSettings();
    if (!s.enabled) {
      return { online: false, enabled: false, studentId: s.studentId, apiUrl: s.apiUrl, bypass_quota: null, last: await getLastIntercept(), paused: false, prompt_bypass: false };
    }
    const client = createFrictionClient(s.apiUrl);
    let last = await getLastIntercept();
    let online = false;
    let quota = null;
    let paused = false;
    const healthP = healthWithin(client, 2e3);
    try {
      const student = await Promise.race([
        client.getStudent(s.studentId),
        new Promise((_, rej) => setTimeout(() => rej(new Error("timeout")), 2e3))
      ]);
      online = true;
      quota = student.user.bypass_quota;
      if (last?.node_id) {
        paused = !!student.states.find((x) => x.node_id === last.node_id)?.paused;
        if (!last.concept_name) {
          await refreshConcepts(client, s.studentId);
          last = { ...last, concept_name: concepts.get(last.node_id) ?? null };
        }
      }
    } catch {
      online = false;
    }
    const prompt_bypass = online && promptBypassEnabled(await healthP, s.promptBypassReadySha);
    return { online, enabled: s.enabled, studentId: s.studentId, apiUrl: s.apiUrl, bypass_quota: quota, last, paused, prompt_bypass };
  }
  async function handleBypass(m) {
    const s = await getSettings();
    if (!s.enabled) return { ok: false, code: "disabled", message: "Friction is turned off." };
    const nodeId = m.node_id ?? (await getLastIntercept())?.node_id;
    if (!nodeId) return { ok: false, code: "no_concept", message: "Ask Claude something first so Friction knows the concept." };
    const client = createFrictionClient(s.apiUrl);
    const wantPrompt = (m.scope ?? "prompt") === "prompt";
    const health = wantPrompt ? await healthWithin(client, 1500) : null;
    const current = await getSettings();
    if (!current.enabled) return { ok: false, code: "disabled", message: "Friction is turned off." };
    if (current.studentId !== s.studentId || current.apiUrl !== s.apiUrl) {
      return { ok: false, code: "settings_changed", message: "Friction settings changed. Nothing was charged; try again in the intended chat." };
    }
    const usePrompt = wantPrompt && promptBypassEnabled(health, current.promptBypassReadySha);
    try {
      const r = await client.bypass(
        usePrompt ? { student_id: s.studentId, node_id: nodeId, scope: "prompt" } : { student_id: s.studentId, node_id: nodeId }
      );
      return { ok: true, remaining_quota: r.remaining_quota, scope_applied: usePrompt ? "prompt" : "concept" };
    } catch (err) {
      if (err instanceof ApiError) return { ok: false, code: err.code, message: err.code === "quota_exhausted" ? "No bypasses left." : err.message };
      return { ok: false, code: "offline", message: "Friction server is unreachable." };
    }
  }
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    const handle = () => {
      switch (msg?.type) {
        case "friction:intercept":
          return handleIntercept(msg);
        case "friction:status":
          return handleStatus();
        case "friction:bypass":
          return handleBypass(msg);
        default:
          return Promise.resolve(void 0);
      }
    };
    handle().then(sendResponse, (err) => sendResponse({ error: String(err) }));
    return true;
  });
})();
