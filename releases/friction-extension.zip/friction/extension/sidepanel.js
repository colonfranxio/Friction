"use strict";
(() => {
  // src/lib/learning-map.ts
  var ALLOWED_DASHBOARD_HOSTS = ["localhost", "127.0.0.1"];
  function buildMapUrl(dashboardUrl, studentId) {
    let base;
    try {
      base = new URL(dashboardUrl.trim());
    } catch {
      return { ok: false, reason: "The Dashboard URL in Friction settings is not a valid address." };
    }
    if (base.protocol !== "http:") {
      return { ok: false, reason: "The Dashboard URL must start with http:// (the local dashboard runs on plain http)." };
    }
    if (!ALLOWED_DASHBOARD_HOSTS.includes(base.hostname)) {
      return {
        ok: false,
        reason: `Friction can only show a dashboard on localhost or 127.0.0.1 (the extension has no access to ${base.hostname}).`
      };
    }
    const id = studentId.trim();
    if (!id) return { ok: false, reason: "No student is set in Friction settings." };
    if (/^\.+$/.test(id)) return { ok: false, reason: "The student ID in Friction settings is not valid." };
    const url = new URL(base.toString());
    url.username = "";
    url.password = "";
    url.pathname = `${url.pathname.replace(/\/+$/, "")}/student/${encodeURIComponent(id)}`;
    url.search = "";
    url.hash = "";
    url.searchParams.set("embed", "1");
    return { ok: true, url: url.toString() };
  }
  function alternateLoopback(url) {
    const u = new URL(url);
    if (u.hostname === "127.0.0.1") u.hostname = "localhost";
    else if (u.hostname === "localhost") u.hostname = "127.0.0.1";
    else return null;
    return u.toString();
  }
  function startLearningMap(deps) {
    let generation = 0;
    let inFlight = null;
    let disposed = false;
    async function reachable(url, g) {
      const ctrl = new AbortController();
      inFlight = ctrl;
      const timer = setTimeout(() => ctrl.abort(), deps.probeTimeoutMs ?? 2500);
      try {
        return await deps.probe(url, ctrl.signal);
      } catch {
        return false;
      } finally {
        clearTimeout(timer);
        if (inFlight === ctrl && g === generation) inFlight = null;
      }
    }
    async function reload() {
      if (disposed) return;
      const g = ++generation;
      inFlight?.abort();
      inFlight = null;
      const s = await deps.getSettings();
      if (g !== generation || disposed) return;
      if (!s.enabled) {
        deps.render({ kind: "off" });
        return;
      }
      const built = buildMapUrl(s.dashboardUrl, s.studentId);
      if (!built.ok) {
        deps.render({ kind: "invalid", reason: built.reason });
        return;
      }
      deps.render({ kind: "loading" });
      const candidates = [built.url, alternateLoopback(built.url)].filter((u) => !!u);
      for (const url of candidates) {
        const ok = await reachable(url, g);
        if (g !== generation || disposed) return;
        if (ok) {
          deps.render({ kind: "frame", url });
          return;
        }
      }
      deps.render({ kind: "unreachable", url: built.url });
    }
    const unsubscribe = deps.onSettingsChange(() => void reload());
    void reload();
    return {
      reload,
      dispose() {
        disposed = true;
        generation++;
        inFlight?.abort();
        unsubscribe();
      }
    };
  }

  // ../../packages/shared/src/constants.ts
  var PORTS = { api: 8787, mock: 8788, dashboard: 5173 };
  var DEFAULT_API_URL = `http://127.0.0.1:${PORTS.api}`;
  var QUIZ_WINDOW_MS = 10 * 60 * 1e3;

  // ../../packages/shared/src/seed.ts
  var SEED_IDS = {
    educator: "11111111-1111-4111-8111-111111111111",
    demoStudent: "22222222-2222-4222-8222-222222222222",
    tree: "33333333-3333-4333-8333-333333333333",
    pillars: {
      foundations: "44444444-4444-4444-8444-000000000001",
      effects: "44444444-4444-4444-8444-000000000002",
      apps: "44444444-4444-4444-8444-000000000003"
    },
    nodes: {
      jsx: "55555555-5555-4555-8555-000000000001",
      props: "55555555-5555-4555-8555-000000000002",
      useState: "55555555-5555-4555-8555-000000000003",
      useEffect: "55555555-5555-4555-8555-000000000004",
      dataFetching: "55555555-5555-4555-8555-000000000005",
      customHooks: "55555555-5555-4555-8555-000000000006",
      context: "55555555-5555-4555-8555-000000000007",
      performance: "55555555-5555-4555-8555-000000000008"
    }
  };
  var N = SEED_IDS.nodes;
  var P = SEED_IDS.pillars;
  var DEMO_STUDENT_LEVELS = {
    [N.jsx]: 3,
    [N.props]: 3,
    [N.useState]: 4,
    [N.useEffect]: 1,
    [N.dataFetching]: 1,
    [N.customHooks]: 1,
    [N.context]: 2,
    [N.performance]: 1
  };

  // src/lib/storage.ts
  var DEFAULT_DASHBOARD_URL = "http://127.0.0.1:5173";
  var DEFAULT_SETTINGS = {
    studentId: SEED_IDS.demoStudent,
    apiUrl: DEFAULT_API_URL,
    enabled: true,
    promptBypassReadySha: "",
    dashboardUrl: DEFAULT_DASHBOARD_URL
  };
  async function getSettings() {
    const s = await chrome.storage.local.get(["studentId", "apiUrl", "enabled", "promptBypassReadySha", "dashboardUrl"]);
    return {
      studentId: typeof s.studentId === "string" && s.studentId ? s.studentId : DEFAULT_SETTINGS.studentId,
      apiUrl: typeof s.apiUrl === "string" && s.apiUrl ? s.apiUrl.replace(/\/$/, "") : DEFAULT_SETTINGS.apiUrl,
      enabled: typeof s.enabled === "boolean" ? s.enabled : DEFAULT_SETTINGS.enabled,
      promptBypassReadySha: typeof s.promptBypassReadySha === "string" ? s.promptBypassReadySha.trim() : "",
      dashboardUrl: typeof s.dashboardUrl === "string" && s.dashboardUrl.trim() ? s.dashboardUrl.trim().replace(/\/+$/, "") : DEFAULT_DASHBOARD_URL
    };
  }

  // src/sidepanel.ts
  var root = document.getElementById("root");
  var WATCHED = ["enabled", "studentId", "dashboardUrl"];
  var controller;
  function message(title, body, retry) {
    root.replaceChildren();
    const box = document.createElement("div");
    box.className = "msg";
    const h = document.createElement("h2");
    h.textContent = title;
    const p = document.createElement("p");
    p.textContent = body;
    box.append(h, p);
    if (retry) {
      const b = document.createElement("button");
      b.textContent = "Retry";
      b.onclick = () => void controller.reload();
      box.append(b);
    }
    root.append(box);
  }
  function render(view) {
    switch (view.kind) {
      case "off":
        return message("Friction is off", "Turn Friction back on in the toolbar popup to see your learning map.", false);
      case "invalid":
        return message("Can\u2019t show the learning map", view.reason + " Fix it in the popup under Settings \u2192 Dashboard URL.", false);
      case "loading":
        return message("Loading your learning map\u2026", "", false);
      case "unreachable":
        return message(
          "Dashboard not reachable",
          `Nothing answered at ${new URL(view.url).origin} (also tried localhost/127.0.0.1). Start it with \u201Cpnpm dev:dash\u201D, or set the right address in the popup under Settings \u2192 Dashboard URL.`,
          true
        );
      case "frame": {
        const existing = root.querySelector("iframe");
        if (existing && existing.src === view.url) return;
        const frame = document.createElement("iframe");
        frame.src = view.url;
        frame.title = "Your learning map";
        root.replaceChildren(frame);
        return;
      }
    }
  }
  controller = startLearningMap({
    getSettings,
    // Extension pages have host access to localhost/127.0.0.1, so a plain GET tells us if the dashboard is up.
    probe: async (url, signal) => {
      try {
        await fetch(new URL(url).origin + "/", { method: "GET", mode: "no-cors", cache: "no-store", signal });
        return true;
      } catch {
        return false;
      }
    },
    onSettingsChange: (cb) => {
      const listener = (changes, area) => {
        if (area !== "local" || !WATCHED.some((k) => k in changes)) return;
        if (changes.enabled && changes.enabled.newValue === false) render({ kind: "off" });
        cb();
      };
      chrome.storage.onChanged.addListener(listener);
      return () => chrome.storage.onChanged.removeListener(listener);
    },
    render
  });
})();
