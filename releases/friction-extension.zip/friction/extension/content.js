"use strict";
(() => {
  var __defProp = Object.defineProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };

  // ../../packages/shared/src/constants.ts
  var PORTS = { api: 8787, mock: 8788, dashboard: 5173 };
  var DEFAULT_API_URL = `http://127.0.0.1:${PORTS.api}`;
  var FRICTION_OPEN = "\u27E6friction\u27E7";
  var FRICTION_CLOSE = "\u27E6/friction\u27E7";
  var EXTENSION_TIMEOUT_MS = 4500;
  var QUIZ_WINDOW_MS = 10 * 60 * 1e3;
  var LEVEL_LABELS = {
    1: { bloom: "Remember / Understand", role: "Socratic", friction: "Max friction" },
    2: { bloom: "Apply", role: "Scaffolder", friction: "Medium friction" },
    3: { bloom: "Analyze / Evaluate", role: "Challenger", friction: "Reverse friction" },
    4: { bloom: "Create", role: "Normal", friction: "No friction" }
  };

  // ../../packages/shared/src/rules.ts
  function wrapInjected(raw, body) {
    return `${raw}

${FRICTION_OPEN}
${body.trim()}
${FRICTION_CLOSE}`;
  }
  function stripInjected(text) {
    const open = escapeRe(FRICTION_OPEN);
    const close = escapeRe(FRICTION_CLOSE);
    return text.replace(new RegExp(`\\s*${open}[\\s\\S]*?${close}`, "g"), "").trimEnd();
  }
  function escapeRe(s) {
    return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }

  // ../../packages/shared/src/seed.ts
  var SEED_IDS = {
    educator: "11111111-1111-4111-8111-111111111111",
    demoStudent: "22222222-2222-4222-8222-222222222222",
    tree: "33333333-3333-4333-8333-333333333333",
    pillars: {
      foundations: "44444444-4444-4444-8444-000000000001",
      effects: "44444444-4444-4444-8444-000000000002",
      apps: "44444444-4444-4444-8444-000000000003"
    },
    nodes: {
      jsx: "55555555-5555-4555-8555-000000000001",
      props: "55555555-5555-4555-8555-000000000002",
      useState: "55555555-5555-4555-8555-000000000003",
      useEffect: "55555555-5555-4555-8555-000000000004",
      dataFetching: "55555555-5555-4555-8555-000000000005",
      customHooks: "55555555-5555-4555-8555-000000000006",
      context: "55555555-5555-4555-8555-000000000007",
      performance: "55555555-5555-4555-8555-000000000008"
    }
  };
  var N = SEED_IDS.nodes;
  var P = SEED_IDS.pillars;
  var DEMO_STUDENT_LEVELS = {
    [N.jsx]: 3,
    [N.props]: 3,
    [N.useState]: 4,
    [N.useEffect]: 1,
    [N.dataFetching]: 1,
    [N.customHooks]: 1,
    [N.context]: 2,
    [N.performance]: 1
  };

  // src/lib/badge.ts
  var DOT = { amber: "#6D4AFF", green: "#E0A100", grey: "#8F86A8", teal: "#0E7A7A" };
  var MARK = { [DOT.amber]: "learning", [DOT.green]: "mastered", [DOT.grey]: "idle", [DOT.teal]: "ticket" };
  function badgeText(s) {
    switch (s.kind) {
      case "active": {
        if (s.level === 4) return { text: `Friction \xB7 no friction${s.concept ? ` \xB7 ${s.concept}` : ""}`, dot: DOT.green };
        const role = LEVEL_LABELS[s.level].role;
        return { text: `Friction \xB7 L${s.level} ${role}${s.concept ? ` \xB7 ${s.concept}` : ""}`, dot: DOT.amber };
      }
      case "none":
        return { text: "Friction \xB7 no friction", dot: DOT.green };
      case "offline":
        return { text: "Friction offline", dot: DOT.grey };
      case "disabled":
        return { text: "Friction paused", dot: DOT.grey };
      case "bypassed": {
        const left = s.remaining === null ? "" : ` \xB7 ${s.remaining} left`;
        const what = s.conceptPaused ? "concept bypassed" : "bypassed";
        return { text: `Friction \xB7 ${what}${s.concept ? ` \xB7 ${s.concept}` : ""}${left}`, dot: DOT.teal };
      }
      case "spent":
        return { text: `Friction \xB7 bypass used (${s.remaining} left), not sent: ${s.reason}`, dot: DOT.amber };
      case "opt-out":
        return { text: "Friction \xB7 to skip friction, use Bypass \xB7 Enter sends anyway", dot: DOT.amber };
      case "error":
        return { text: `Friction \xB7 ${s.message}`, dot: DOT.amber };
      case "reload":
        return { text: "Friction updated \xB7 reload this tab", dot: DOT.amber };
      default:
        return { text: "Friction \xB7 ready", dot: DOT.green };
    }
  }
  function badgeMark(s) {
    return s.kind === "error" || s.kind === "reload" ? "alert" : MARK[badgeText(s).dot] ?? "idle";
  }
  function canBypass(s) {
    return s.kind === "active" && s.level < 4 || s.kind === "opt-out";
  }
  function mountBadge(doc, opts = {}) {
    const host = doc.createElement("friction-badge");
    host.setAttribute("data-friction", "badge");
    const root = host.attachShadow({ mode: "open" });
    root.innerHTML = `
    <style>
      :host { all: initial; position: fixed; right: 12px; bottom: 12px; z-index: 2147483646; pointer-events: none; }
      .pill { display: inline-flex; align-items: center; gap: 8px; padding: 6px 12px; border-radius: 999px;
        background: #FFFFFF; color: #231B3A; border: 1.5px solid #E2DCEC; box-shadow: 0 2px 10px rgba(35,27,58,.12);
        font: 700 12px/1.2 Nunito, ui-rounded, system-ui, sans-serif; max-width: 440px; white-space: nowrap; }
      .text { min-width: 0; overflow: hidden; text-overflow: ellipsis; }
      .mark { width: 9px; height: 12px; border-radius: 2.5px; flex: none; transform: rotate(-8deg); box-sizing: border-box; }
      .mark[data-mark="learning"] { background: #6D4AFF; border: 1.5px solid #4B2FB8; }
      .mark[data-mark="mastered"] { background: #E0A100; border: 1.5px solid #B07A00; }
      .mark[data-mark="ticket"] { background: #E6F4F3; border: 1.5px dashed #0E7A7A; transform: none; }
      .mark[data-mark="idle"] { background: #EBE7F2; border: 1.5px dashed #8F86A8; transform: none; }
      .mark[data-mark="alert"] { background: #FFFFFF; border: 1.5px solid #6D4AFF; }
      .bypass { pointer-events: auto; margin-left: 4px; padding: 2px 10px; border-radius: 999px; border: 1.5px dashed #0E7A7A;
        background: #E6F4F3; color: #0E7A7A; font: 800 11px/1.4 Nunito, ui-rounded, system-ui, sans-serif; cursor: pointer; }
      .bypass:hover { background: #D6EEEC; }
      .bypass:focus-visible { outline: 2px solid #A993FF; outline-offset: 2px; }
      .bypass:disabled { opacity: .5; cursor: default; }
      .bypass[hidden] { display: none; }
    </style>
    <div class="pill"><span class="mark" aria-hidden="true"></span><span class="text"></span>
      <button class="bypass" type="button" title="Re-send this message without friction. On this server it also pauses friction on this concept until reset. Uses one bypass; your teacher is notified." hidden>Bypass</button>
      <button class="bypass copy" type="button" title="Copy your original question" hidden>Copy question</button></div>`;
    const mark = root.querySelector(".mark");
    const text = root.querySelector(".text");
    const btn = root.querySelector(".bypass");
    const copy = root.querySelector(".copy");
    let copyText = "";
    copy.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      void navigator.clipboard?.writeText(copyText).then(
        () => copy.textContent = "Copied",
        () => copy.textContent = "Copy failed"
      );
    });
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (!btn.disabled) opts.onBypass?.();
    });
    const set = (state) => {
      const t = badgeText(state);
      text.textContent = t.text;
      mark.dataset.mark = badgeMark(state);
      btn.hidden = !opts.onBypass || !canBypass(state);
      copyText = state.kind === "spent" ? state.prompt : "";
      copy.hidden = !copyText;
      copy.textContent = "Copy question";
    };
    const setBusy = (busy) => {
      btn.disabled = busy;
      btn.textContent = busy ? "Bypassing\u2026" : "Bypass";
    };
    set({ kind: "ready" });
    (doc.body ?? doc.documentElement).appendChild(host);
    const setPromptBypass = (on) => {
      btn.title = on ? "Re-send this message without friction (uses one bypass; your teacher is notified)." : "Re-send this message without friction. On this server it also pauses friction on this concept until reset. Uses one bypass; your teacher is notified.";
    };
    return { set, setBusy, setPromptBypass, host };
  }

  // src/lib/conversation.ts
  var ALIAS_KEY = "friction:conversation-aliases";
  var ASSIGN_WINDOW_MS = 15e3;
  function createConversationTracker(deps) {
    const now = deps.now ?? Date.now;
    let aliases = {};
    try {
      aliases = JSON.parse(deps.store?.getItem(ALIAS_KEY) ?? "{}") ?? {};
    } catch {
      aliases = {};
    }
    const save = () => {
      try {
        deps.store?.setItem(ALIAS_KEY, JSON.stringify(aliases));
      } catch {
      }
    };
    let unsaved = null;
    let lastPath = deps.getPath();
    const alias = (real, id) => {
      aliases[real] = id;
      save();
    };
    function onPath(pathname) {
      if (pathname === lastPath) return;
      lastPath = pathname;
      if (!unsaved) return;
      const real = deps.idFromPath(pathname);
      const fresh = !!real && !aliases[real];
      if (fresh && unsaved.state === "sending" && !unsaved.uuid) {
        unsaved.uuid = real;
        return;
      }
      if (fresh && unsaved.state === "sent" && now() - (unsaved.sentAt ?? 0) <= ASSIGN_WINDOW_MS) alias(real, unsaved.id);
      unsaved = null;
    }
    function currentId() {
      const path = deps.getPath();
      onPath(path);
      const real = deps.idFromPath(path);
      if (real) return aliases[real] ?? (unsaved?.uuid === real ? unsaved.id : real);
      return unsaved && unsaved.path === path ? unsaved.id : null;
    }
    return {
      idForSend() {
        const id = currentId();
        if (unsaved && id === unsaved.id) unsaved.state = "sending";
        if (id) return id;
        unsaved = { id: deps.newId(), path: deps.getPath(), state: "sending" };
        return unsaved.id;
      },
      currentId,
      endSend(sent) {
        if (unsaved?.state !== "sending") return;
        if (!sent) {
          if (unsaved.uuid) unsaved = null;
          else unsaved.state = "idle";
          return;
        }
        if (unsaved.uuid) {
          alias(unsaved.uuid, unsaved.id);
          unsaved = null;
        } else {
          unsaved.state = "sent";
          unsaved.sentAt = now();
        }
      },
      onPath
    };
  }

  // src/lib/hide-injected.ts
  function isSkipped(node) {
    let el = node.parentElement;
    while (el) {
      const tag = el.tagName;
      if (tag === "TEXTAREA" || tag === "INPUT" || tag === "SCRIPT" || tag === "STYLE") return true;
      if (el.getAttribute("contenteditable") === "true" || el.getAttribute("contenteditable") === "") return true;
      if (el.getAttribute("data-friction") === "badge") return true;
      el = el.parentElement;
    }
    return false;
  }
  function textNodes(root) {
    const doc = root.ownerDocument ?? root;
    const walker = doc.createTreeWalker(
      root,
      4
      /* NodeFilter.SHOW_TEXT */
    );
    const out = [];
    for (let n = walker.nextNode(); n; n = walker.nextNode()) out.push(n);
    return out;
  }
  function stripFrictionBlocks(root) {
    let removed = 0;
    for (let guard = 0; guard < 20; guard++) {
      const nodes = textNodes(root).filter((n) => !isSkipped(n));
      const startIdx = nodes.findIndex((n) => n.data.includes(FRICTION_OPEN));
      if (startIdx === -1) break;
      let endIdx = -1;
      for (let i = startIdx; i < nodes.length; i++) {
        const from = i === startIdx ? nodes[i].data.indexOf(FRICTION_OPEN) : 0;
        if (nodes[i].data.indexOf(FRICTION_CLOSE, from) !== -1) {
          endIdx = i;
          break;
        }
      }
      if (endIdx === -1) break;
      const start = nodes[startIdx];
      const openAt = start.data.indexOf(FRICTION_OPEN);
      if (startIdx === endIdx) {
        const closeAt = start.data.indexOf(FRICTION_CLOSE, openAt) + FRICTION_CLOSE.length;
        start.data = start.data.slice(0, openAt).trimEnd() + start.data.slice(closeAt);
      } else {
        start.data = start.data.slice(0, openAt).trimEnd();
        for (let i = startIdx + 1; i < endIdx; i++) nodes[i].data = "";
        const end = nodes[endIdx];
        end.data = end.data.slice(end.data.indexOf(FRICTION_CLOSE) + FRICTION_CLOSE.length);
      }
      removed++;
    }
    return removed;
  }
  function startHidingInjected(doc) {
    let scheduled = false;
    const run = () => {
      scheduled = false;
      if (doc.body) stripFrictionBlocks(doc.body);
    };
    const schedule = () => {
      if (scheduled) return;
      scheduled = true;
      (doc.defaultView?.requestAnimationFrame ?? ((f) => setTimeout(f, 16)))(run);
    };
    const obs = new MutationObserver(schedule);
    obs.observe(doc.documentElement, { childList: true, subtree: true, characterData: true });
    schedule();
    return () => obs.disconnect();
  }

  // src/lib/bypass-flow.ts
  var ARMED_TTL_MS = 2 * 60 * 1e3;
  var REASONS = {
    disabled: "Friction was turned off",
    stale: "you switched chats",
    draft: "you started a new draft",
    busy: "another message was sending",
    sent: "another message was sent",
    no_composer: "the message box was not found",
    changed: "the page changed"
  };
  function createBypassFlow(deps) {
    const now = deps.now ?? Date.now;
    let target = null;
    let armed = null;
    let bypassing = false;
    let sends = 0;
    const sameChat = (t) => deps.currentConversation() === t.conv;
    function blocker(t) {
      if (!deps.isEnabled()) return "disabled";
      if (!sameChat(t)) return "stale";
      const can = deps.interceptor.canSendUnmodified(t.raw);
      return can === "ok" ? null : can;
    }
    function spentNotSent(t, r, reason) {
      deps.badge.set({ kind: "spent", remaining: r.remaining_quota, reason: REASONS[reason], prompt: t.raw });
      return { ok: true, remaining_quota: r.remaining_quota, resent: false, scope_applied: r.scope_applied, not_sent_reason: REASONS[reason], prompt: t.raw };
    }
    async function run() {
      const t = target;
      if (!t) return { ok: false, code: "no_prompt", message: "Nothing to bypass in this tab yet." };
      if (bypassing) return { ok: false, code: "busy", message: "Bypass already in progress." };
      const before = blocker(t);
      if (before === "stale") {
        target = null;
        deps.badge.set({ kind: "ready" });
        return { ok: false, code: "stale", message: "That message was in another chat." };
      }
      if (before === "disabled") return { ok: false, code: "disabled", message: "Friction is turned off." };
      if (before === "draft") {
        deps.badge.set({ kind: "error", message: "clear your draft to bypass" });
        return { ok: false, code: "draft", message: "Send or clear your new draft first, then bypass." };
      }
      if (before === "no_composer") return { ok: false, code: "no_composer", message: "Message box not found. Reload the claude.ai tab." };
      if (before) return { ok: false, code: "busy", message: "Wait for the current message to send, then bypass." };
      bypassing = true;
      deps.badge.setBusy(true);
      const sendsBefore = sends;
      try {
        let r;
        try {
          r = await deps.requestBypass(t.node_id);
        } catch (e) {
          deps.badge.set(deps.isContextInvalidated(e) ? { kind: "reload" } : { kind: "error", message: "server unreachable" });
          return { ok: false, code: "offline", message: "Friction server is unreachable." };
        }
        if (!r.ok) {
          deps.badge.set({ kind: "error", message: r.code === "quota_exhausted" ? "no bypasses left" : "bypass failed" });
          return r;
        }
        if (target === t) target = null;
        const after = blocker(t) ?? (sends !== sendsBefore ? "sent" : null);
        if (after) return spentNotSent(t, r, after);
        const sent = await deps.interceptor.sendUnmodified(t.raw, () => deps.isEnabled() && sameChat(t) && sends === sendsBefore);
        if (sent === "aborted") return spentNotSent(t, r, blocker(t) ?? (sends !== sendsBefore ? "sent" : "changed"));
        if (sent === "not-sent") armed = { text: t.raw, conv: t.conv, until: now() + ARMED_TTL_MS };
        deps.badge.set({ kind: "bypassed", concept: t.concept, remaining: r.remaining_quota, conceptPaused: r.scope_applied === "concept" });
        return { ok: true, remaining_quota: r.remaining_quota, resent: sent === "sent", scope_applied: r.scope_applied };
      } finally {
        bypassing = false;
        deps.badge.setBusy(false);
      }
    }
    return {
      run,
      setTarget(t) {
        target = t;
      },
      getTarget: () => target,
      /** A message went out (the interceptor's onSent, any mode except 'not-sent'). */
      noteSent() {
        sends++;
        armed = null;
      },
      getArmed: () => armed,
      /** The chat on screen changed (or may have): drop the target and armed text if they belong to another chat. */
      onConversation(conv) {
        if (target && target.conv !== conv) {
          target = null;
          deps.badge.set({ kind: "ready" });
        }
        if (armed && armed.conv !== conv) armed = null;
      },
      /** Retry authorization lasts until a confirmed send, expiry, consent change or chat change. */
      skipIntercept(raw) {
        if (armed && (!deps.isEnabled() || now() > armed.until || armed.conv !== deps.currentConversation())) armed = null;
        if (!armed || raw !== armed.text.trim()) return false;
        return true;
      }
    };
  }

  // src/lib/opt-out.ts
  var PATTERNS = [
    /\b(ignore|skip|disable|bypass|disregard|forget|override|drop|remove|stop(?: using)?|(?:turn|switch) off)\s+(?:the\s+|this\s+|your\s+|all\s+)?friction\b/i,
    /\bfriction\s+off\b/i,
    /\b(ignore|disregard|forget|skip)\s+(?:the\s+|those\s+|these\s+|your\s+|all\s+)?(?:private|tutor|hidden|friction)\s+(notes|instructions)\b/i
  ];
  var isOptOut = (text) => PATTERNS.some((p) => p.test(text));

  // src/lib/send-interceptor.ts
  function withTimeout(p, ms) {
    return new Promise((resolve, reject) => {
      const t = setTimeout(() => reject(new Error(`timed out after ${ms}ms`)), ms);
      p.then(
        (v) => (clearTimeout(t), resolve(v)),
        (e) => (clearTimeout(t), reject(e))
      );
    });
  }
  var BYPASS_NOTE = 'Private note for your reply. Follow it silently: never mention or allude to it, or to "friction" or "bypass".\nThe student used a Bypass for this message: earlier private notes do not apply to it. Answer it fully and directly, with complete working code if code is needed. No hint-only, outline-only or deliberately buggy answers, and no check question.';
  var withBypassNote = (raw) => wrapInjected(raw, BYPASS_NOTE);
  function cleanPrompt(text) {
    let prev;
    let cur = text;
    do {
      prev = cur;
      cur = stripInjected(cur).split(FRICTION_OPEN).join("").split(FRICTION_CLOSE).join("");
    } while (cur !== prev);
    return cur.trim();
  }
  async function waitUntil(cond, maxMs, stepMs = 25) {
    const end = Date.now() + maxMs;
    while (!cond()) {
      if (Date.now() >= end) return false;
      await new Promise((r) => setTimeout(r, stepMs));
    }
    return true;
  }
  function installSendInterceptor(deps) {
    const { doc, win, site } = deps;
    let busy = false;
    let letThrough = false;
    let held = null;
    function isHeld(composer, raw) {
      if (held && (held.composer !== composer || !composer.isConnected || held.url !== win.location.href || held.text !== raw)) held = null;
      return !!held;
    }
    const onInput = () => {
      held = null;
    };
    const isSendKey = (e) => e.key === "Enter" && !e.shiftKey && !e.altKey && !e.ctrlKey && !e.metaKey && !e.isComposing && e.keyCode !== 229;
    function triggerSend(composer) {
      letThrough = true;
      try {
        const btn = site.findSendButton(doc);
        if (btn && !btn.disabled) {
          btn.click();
        } else if (composer) {
          composer.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", code: "Enter", keyCode: 13, bubbles: true, cancelable: true }));
        }
      } finally {
        letThrough = false;
      }
    }
    const buttonReady = () => {
      const b = site.findSendButton(doc);
      return !!b && !b.disabled;
    };
    async function sendAndConfirm(composer, raw) {
      await waitUntil(buttonReady, deps.settleMs ?? 300);
      triggerSend(composer);
      const sent = await waitUntil(() => !site.getComposerText(composer).includes(FRICTION_OPEN), deps.confirmMs ?? 600);
      if (!sent) await site.setComposerText(doc, composer, raw).catch(() => false);
      return sent;
    }
    async function sendClean(composer, typed, raw) {
      if (raw !== typed) {
        await site.setComposerText(doc, composer, raw).catch(() => false);
        await waitUntil(buttonReady, deps.settleMs ?? 300);
      }
      triggerSend(composer);
    }
    async function run() {
      const composer = site.findComposer(doc);
      const typed = composer ? site.getComposerText(composer).trim() : "";
      if (!composer || !typed) {
        triggerSend(composer);
        return;
      }
      const raw = cleanPrompt(typed);
      if (!raw) {
        await site.setComposerText(doc, composer, "").catch(() => false);
        return;
      }
      if (deps.skipIntercept?.(raw)) {
        held = null;
        const url = win.location.href;
        const unchanged = () => composer.isConnected && site.findComposer(doc) === composer && win.location.href === url && cleanPrompt(site.getComposerText(composer)) === raw;
        const ok2 = await site.setComposerText(doc, composer, withBypassNote(raw)).catch(() => false);
        await waitUntil(buttonReady, deps.settleMs ?? 300);
        if (!unchanged()) {
          deps.onSent?.("not-sent", null);
          return;
        }
        if (!ok2 || !buttonReady() || deps.canSendBypass?.() === false) {
          await site.setComposerText(doc, composer, raw).catch(() => false);
          deps.onSent?.("not-sent", null);
          return;
        }
        triggerSend(composer);
        const sent2 = await waitUntil(() => cleanPrompt(site.getComposerText(composer)) !== raw, deps.confirmMs ?? 600);
        if (!sent2 && unchanged()) await site.setComposerText(doc, composer, raw).catch(() => false);
        deps.onSent?.(sent2 ? "bypassed" : "not-sent", null);
        return;
      }
      if (!isHeld(composer, raw) && deps.holdBack?.(raw)) {
        held = { text: raw, composer, url: win.location.href };
        return;
      }
      held = null;
      let result;
      try {
        result = await withTimeout(deps.intercept(raw), deps.timeoutMs);
      } catch {
        await sendClean(composer, typed, raw);
        deps.onSent?.("failed-open", null);
        return;
      }
      const o = result.outcome;
      if (o.passthrough || o.response.injected_prompt === raw) {
        await sendClean(composer, typed, raw);
        deps.onSent?.("passthrough", result);
        return;
      }
      const ok = await site.setComposerText(doc, composer, o.response.injected_prompt).catch(() => false);
      if (!ok) {
        await site.setComposerText(doc, composer, raw).catch(() => false);
        await waitUntil(buttonReady, deps.settleMs ?? 300);
        triggerSend(composer);
        deps.onSent?.("failed-open", result);
        return;
      }
      const sent = await sendAndConfirm(composer, raw);
      deps.onSent?.(sent ? "injected" : "not-sent", result);
    }
    function hold(e) {
      e.preventDefault();
      e.stopImmediatePropagation();
      if (busy) return;
      busy = true;
      run().finally(() => busy = false);
    }
    const onKeyDown = (e) => {
      if (letThrough || !isSendKey(e) || !site.isInComposer(e.target, doc)) return;
      hold(e);
    };
    const onClick = (e) => {
      if (letThrough || !site.isOnSendButton(e.target, doc)) return;
      hold(e);
    };
    win.addEventListener("keydown", onKeyDown, true);
    win.addEventListener("click", onClick, true);
    win.addEventListener("input", onInput, true);
    const uninstall = () => {
      win.removeEventListener("keydown", onKeyDown, true);
      win.removeEventListener("click", onClick, true);
      win.removeEventListener("input", onInput, true);
    };
    return Object.assign(uninstall, {
      canSendUnmodified(text) {
        const composer = site.findComposer(doc);
        if (!composer) return "no_composer";
        if (busy) return "busy";
        const current = cleanPrompt(site.getComposerText(composer));
        if (current && current !== text.trim() && !isHeld(composer, current)) return "draft";
        return "ok";
      },
      async sendUnmodified(text, stillValid = () => true) {
        const composer = site.findComposer(doc);
        const want = text.trim();
        if (!composer || busy || !stillValid()) return "aborted";
        const sameComposer = () => composer.isConnected && site.findComposer(doc) === composer;
        if (!sameComposer()) return "aborted";
        const before = site.getComposerText(composer);
        const current = cleanPrompt(before);
        if (current && current !== want && !isHeld(composer, current)) return "aborted";
        held = null;
        busy = true;
        try {
          if (!sameComposer()) return "aborted";
          const ok = await site.setComposerText(doc, composer, withBypassNote(want)).catch(() => false);
          if (!sameComposer()) return "aborted";
          if (!ok) return "not-sent";
          await waitUntil(buttonReady, deps.settleMs ?? 300);
          if (!sameComposer()) return "aborted";
          if (cleanPrompt(site.getComposerText(composer)) !== want) return "aborted";
          const valid = stillValid();
          if (!sameComposer()) return "aborted";
          if (!valid) {
            await site.setComposerText(doc, composer, before).catch(() => false);
            return "aborted";
          }
          triggerSend(composer);
          const sent = await waitUntil(() => cleanPrompt(site.getComposerText(composer)) !== want, deps.confirmMs ?? 600);
          return sent ? "sent" : "not-sent";
        } finally {
          busy = false;
        }
      }
    });
  }

  // src/site/claude.ts
  var claude_exports = {};
  __export(claude_exports, {
    SELECTORS: () => SELECTORS,
    conversationIdFromPath: () => conversationIdFromPath,
    findComposer: () => findComposer,
    findSendButton: () => findSendButton,
    getComposerText: () => getComposerText,
    isInComposer: () => isInComposer,
    isOnSendButton: () => isOnSendButton,
    lastAssistantText: () => lastAssistantText,
    setComposerText: () => setComposerText
  });
  var SELECTORS = {
    composer: ['div.ProseMirror[contenteditable="true"]', '[contenteditable="true"][role="textbox"]', 'fieldset [contenteditable="true"]'],
    send: ['button[aria-label*="Send" i]', 'fieldset button[type="submit"]'],
    assistant: ['[data-testid="assistant-message"]', ".font-claude-response", ".font-claude-message", "[data-is-streaming]"]
  };
  var MAX_ASSISTANT_CHARS = 4e3;
  function first(doc, sels) {
    for (const s of sels) {
      const el = doc.querySelector(s);
      if (el) return el;
    }
    return null;
  }
  function findComposer(doc) {
    return first(doc, SELECTORS.composer);
  }
  function findSendButton(doc) {
    return first(doc, SELECTORS.send);
  }
  function isInComposer(target, doc) {
    const c = findComposer(doc);
    return !!c && target instanceof Node && (c === target || c.contains(target));
  }
  function isOnSendButton(target, doc) {
    const b = findSendButton(doc);
    return !!b && target instanceof Node && (b === target || b.contains(target));
  }
  function getComposerText(el) {
    return (el.innerText ?? el.textContent ?? "").replace(/\u00a0/g, " ");
  }
  var norm = (s) => s.replace(/\s+/g, " ").trim();
  var log = (strategy) => (console.debug("[friction] composer rewritten via", strategy), true);
  function composerHas(el, text) {
    return norm(getComposerText(el)) === norm(text);
  }
  function selectAll(doc, el) {
    el.focus();
    const sel = doc.getSelection();
    if (!sel) return;
    const range = doc.createRange();
    range.selectNodeContents(el);
    sel.removeAllRanges();
    sel.addRange(range);
  }
  async function setComposerText(doc, el, text) {
    const settle = () => new Promise((r) => setTimeout(r, 0));
    try {
      selectAll(doc, el);
      const dt = new DataTransfer();
      dt.setData("text/plain", text);
      el.dispatchEvent(new ClipboardEvent("paste", { clipboardData: dt, bubbles: true, cancelable: true }));
      await settle();
      if (composerHas(el, text)) return log("paste");
    } catch {
    }
    try {
      selectAll(doc, el);
      if (typeof doc.execCommand === "function" && doc.execCommand("insertText", false, text)) {
        await settle();
        if (composerHas(el, text)) return log("insertText");
      }
    } catch {
    }
    const lines = text.split("\n");
    el.replaceChildren(
      ...lines.map((line) => {
        const p = doc.createElement("p");
        p.textContent = line;
        return p;
      })
    );
    el.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertFromPaste" }));
    await settle();
    return composerHas(el, text) ? log("dom") : false;
  }
  function conversationIdFromPath(pathname) {
    const m = /\/chat\/([0-9a-fA-F-]{36})(?:[/?#]|$)/.exec(pathname);
    return m ? m[1] : null;
  }
  function lastAssistantText(doc) {
    for (const sel of SELECTORS.assistant) {
      const all = doc.querySelectorAll(sel);
      const last = all[all.length - 1];
      const text = (last?.innerText ?? last?.textContent ?? "").trim();
      if (text && !text.includes(FRICTION_OPEN)) return text.slice(-MAX_ASSISTANT_CHARS);
    }
    return null;
  }

  // src/content.ts
  function isContextInvalidated(err) {
    try {
      if (!chrome.runtime?.id) return true;
    } catch {
      return true;
    }
    return /context invalidated/i.test(String(err?.message ?? err ?? ""));
  }
  var lastError = null;
  function send(msg) {
    try {
      return chrome.runtime.sendMessage(msg).catch((e) => {
        lastError = e;
        throw e;
      });
    } catch (e) {
      lastError = e;
      return Promise.reject(e);
    }
  }
  var badge = mountBadge(document, { onBypass: () => void bypass.run() });
  var pendingRaw = "";
  var pendingConv = "";
  var enabled = true;
  try {
    chrome.storage.local.get("enabled").then((s) => enabled = s.enabled !== false, () => {
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && "enabled" in changes) enabled = changes.enabled.newValue !== false;
    });
  } catch {
  }
  var conversations = createConversationTracker({
    idFromPath: conversationIdFromPath,
    getPath: () => location.pathname,
    newId: () => crypto.randomUUID(),
    store: (() => {
      try {
        return window.sessionStorage;
      } catch {
        return null;
      }
    })()
  });
  function badgeFor(mode, r) {
    if (mode === "bypassed") return { kind: "bypassed", concept: null, remaining: null };
    if (mode === "not-sent") return { kind: "ready" };
    if ((mode === "failed-open" || !r) && isContextInvalidated(lastError)) return { kind: "reload" };
    if (mode === "failed-open" || !r) return { kind: "offline" };
    const o = r.outcome;
    if (!o.passthrough && o.response.level) return { kind: "active", level: o.response.level, concept: r.concept_name };
    if (o.passthrough && o.reason === "offline") return { kind: "offline" };
    if (o.passthrough && o.reason === "disabled") return { kind: "disabled" };
    return { kind: "none" };
  }
  var interceptor = installSendInterceptor({
    doc: document,
    win: window,
    site: claude_exports,
    timeoutMs: EXTENSION_TIMEOUT_MS,
    skipIntercept: (raw) => bypass.skipIntercept(raw),
    canSendBypass: () => enabled,
    // "Ignore friction for this" while this chat has friction: Claude would obey, so hold it and offer Bypass.
    holdBack: (raw) => enabled && !!bypass.getTarget() && isOptOut(raw) && (badge.set({ kind: "opt-out" }), true),
    intercept: (raw) => (pendingRaw = raw, pendingConv = conversations.idForSend(), send({
      type: "friction:intercept",
      raw_prompt: raw,
      conversation_id: pendingConv,
      previous_assistant_text: lastAssistantText(document)
    })),
    onSent: (mode, r) => {
      if (mode !== "bypassed") conversations.endSend(mode !== "not-sent");
      if (mode !== "not-sent") bypass.noteSent();
      if (mode === "injected" && r && !r.outcome.passthrough && r.outcome.response.node_id && r.outcome.response.level !== 4) {
        bypass.setTarget({ raw: pendingRaw, node_id: r.outcome.response.node_id, concept: r.concept_name, conv: pendingConv });
      } else if (mode !== "not-sent" && mode !== "bypassed") {
        bypass.setTarget(null);
      }
      badge.set(badgeFor(mode, r));
    }
  });
  var bypass = createBypassFlow({
    interceptor,
    currentConversation: () => conversations.currentId(),
    isEnabled: () => enabled,
    requestBypass: (node_id) => send({ type: "friction:bypass", node_id, scope: "prompt" }),
    badge,
    isContextInvalidated
  });
  setInterval(() => bypass.onConversation(conversations.currentId()), 500);
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg?.type !== "friction:bypass-resend") return false;
    bypass.run().then(sendResponse);
    return true;
  });
  startHidingInjected(document);
  send({ type: "friction:status" }).then((s) => {
    badge.setPromptBypass(!!s.prompt_bypass);
    if (!s.enabled) badge.set({ kind: "disabled" });
    else if (!s.online) badge.set({ kind: "offline" });
  }).catch((e) => badge.set(isContextInvalidated(e) ? { kind: "reload" } : { kind: "offline" }));
})();
